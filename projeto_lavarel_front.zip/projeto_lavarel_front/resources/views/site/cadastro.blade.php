@extends('site.layouts.basico')

@section('titulo', 'Cadastro')

@section('conteudo')

    <div class="d-flex">
        <div class="w-100 d-flex flex-column align-items-center justify-content-center">
            <div class="w-50">
                <h1 class="titulo-cadastro-login mb-5">Cadastre-se</h1>
                <form action="" class="d-flex flex-column">
                    <input class="input-cadastro-login" type="text" name="name" id="name" placeholder="Nome e sobrenome">
                    <input class="my-3  input-cadastro-login" type="email" name="email" id="email" placeholder="E-mail">
                    <input class="input-cadastro-login" type="text" name="phone" id="phone" placeholder="Telefone/Celular">
                    <input class="my-3 input-cadastro-login" type="password" name="password" id="password" placeholder="Senha">
                    <input class="input-cadastro-login" type="password" name="confirm_password" id="confirm_password" placeholder="Confirmar senha">
                    
                    <button class="btn-blue-login my-5">Cadastrar</button>
                </form>

                <p class="p-login">Já tem uma conta? <a class="p-login" href="{{ route('site.login') }}">Acesse aqui!</a></p>
            </div>
        </div>
        <div><img src="{{ asset('img/Rectangle 36.png') }}" alt="ImgCadastroLogin" width="800"></div>
    </div>

@endsection