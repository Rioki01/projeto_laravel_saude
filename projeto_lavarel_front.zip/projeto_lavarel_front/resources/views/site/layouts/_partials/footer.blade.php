<div class="footer px-5 py-2 d-flex justify-content-between align-items-center">
    <div class="titulo">
        CheckMed
    </div>
    <div class="text">
        Grupo Genérico, 2024.
    </div>
</div>