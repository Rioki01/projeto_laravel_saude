

<?php $__env->startSection('titulo', 'Interno'); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="d-flex w-100">
        <div class="w-auto">
            <div class="sidebar d-flex flex-column justify-content-between">
                <div>
                    <h1>CheckMed</h1>
                    <div>
                        <a href="">
                            <button>Agendar consulta</button>
                        </a>
                        <a href="">
                            <button>Agendados</button>
                        </a>
                        <a href="">
                            <button>Médicos</button>
                        </a>
                    </div>
                </div>
                <div>
                    <a href="<?php echo e(route('site.index')); ?>"><button class="btns btn-white">Sair</button></a>
                </div>
            </div>
        </div>
        <div><img src="<?php echo e(asset('img/Rectangle 36.png')); ?>" alt="ImgCadastroLogin" width="800"></div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\flavi\Documents\Faculdade\projeto_lavarel_front\resources\views/interno/home.blade.php ENDPATH**/ ?>