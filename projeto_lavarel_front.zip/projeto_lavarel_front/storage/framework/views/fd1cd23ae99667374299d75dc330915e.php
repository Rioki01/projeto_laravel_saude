<div class="d-flex w-100 justify-content-between p-5">
    <div>
        <h1 class="logo">CheckMed</h1>
    </div>

    <div>
        <a class="px-2" href="<?php echo e(route('site.cadastro')); ?>"><button class="btns btn-blue">Cadastre-se</button></a>
        <a href="<?php echo e(route('site.login')); ?>"><button class="btns btn-white">Login</button></a>
    </div>
</div><?php /**PATH C:\Users\flavi\Documents\Faculdade\projeto_lavarel_front\resources\views/site/layouts/_partials/header.blade.php ENDPATH**/ ?>